extends CharacterBody2D
# ─── Tuning ───────────────────────────────────────────────────────────────────
const MOVE_SPEED      := 200.0
const JUMP_VELOCITY   := -300.0
const DOUBLE_JUMP_VELOCITY := -260.0
const GRAVITY         := 700.0
const TILT_UP_DEG     := -25.0
const TILT_DOWN_DEG   :=  25.0
const TILT_SPEED      := 12.0
const LAND_SQUASH_X   := 1.45
const LAND_SQUASH_Y   := 0.60
const LAUNCH_SQUASH_X := 0.70
const LAUNCH_SQUASH_Y := 1.45
const SQUASH_DURATION := 0.18
const MAX_JUMPS       := 2

const DASH_SPEED       := 500.0
const DASH_DURATION    := 0.18
const DASH_COOLDOWN    := 0.5

# ─── State ────────────────────────────────────────────────────────────────────
var _was_on_floor := true
var _facing_right := true
var _squash_tween : Tween
var _land_cooldown := 0.0
var _jumps_used := 0
@onready var _sprite : AnimatedSprite2D = $AnimatedSprite2D
var _jump_particles : CPUParticles2D
var _land_particles : CPUParticles2D
var _double_jump_particles : CPUParticles2D

var _is_dashing := false
var _dash_timer := 0.0
var _dash_cooldown_timer := 0.0
var _dash_particles : CPUParticles2D

func _ready() -> void:
	_jump_particles = _create_dust_particles(Vector2(0, -1), 60.0, 120.0)
	_land_particles = _create_dust_particles(Vector2(0, -1), 180.0, 160.0)
	_double_jump_particles = _create_burst_particles()
	_dash_particles = _create_dash_particles()

func _physics_process(delta: float) -> void:
	if _land_cooldown > 0.0:
		_land_cooldown -= delta
	if _dash_cooldown_timer > 0.0:
		_dash_cooldown_timer -= delta

	if _is_dashing:
		_dash_timer -= delta
		if _dash_timer <= 0.0:
			_is_dashing = false
	elif not is_on_floor():
		velocity.y += GRAVITY * delta

	# CHANGED: action name matches your input map, "Dash"
	if Input.is_action_just_pressed("Dash") and not _is_dashing and _dash_cooldown_timer <= 0.0:
		_start_dash()

	if Input.is_action_just_pressed("jump"):
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
			_jumps_used = 1
			_on_launch()
		elif _jumps_used < MAX_JUMPS:
			velocity.y = DOUBLE_JUMP_VELOCITY
			_jumps_used += 1
			_on_double_jump()

	if not _is_dashing:
		var dir := Input.get_axis("left", "right")
		velocity.x = dir * MOVE_SPEED
		if dir > 0:
			_facing_right = true
			_sprite.flip_h = false
		elif dir < 0:
			_facing_right = false
			_sprite.flip_h = true

	move_and_slide()
	if is_on_floor() and not _was_on_floor and _land_cooldown <= 0.0:
		_on_land()
	if is_on_floor():
		_jumps_used = 0
	_was_on_floor = is_on_floor()
	_update_tilt(delta)

func _start_dash() -> void:
	_is_dashing = true
	_dash_timer = DASH_DURATION
	_dash_cooldown_timer = DASH_COOLDOWN
	var dash_dir := 1.0 if _facing_right else -1.0
	velocity.x = DASH_SPEED * dash_dir
	velocity.y = 0.0
	_dash_particles.direction = Vector2(-dash_dir, 0)
	_dash_particles.restart()

func _squash_then_recover(squash: Vector2) -> void:
	if _squash_tween:
		_squash_tween.kill()
	_sprite.scale = squash
	_squash_tween = create_tween()
	_squash_tween.tween_property(_sprite, "scale", Vector2.ONE, SQUASH_DURATION) \
		.set_trans(Tween.TRANS_ELASTIC) \
		.set_ease(Tween.EASE_OUT)

func _on_launch() -> void:
	_squash_then_recover(Vector2(LAUNCH_SQUASH_X, LAUNCH_SQUASH_Y))
	_jump_particles.restart()

func _on_double_jump() -> void:
	_squash_then_recover(Vector2(LAUNCH_SQUASH_X, LAUNCH_SQUASH_Y))
	_double_jump_particles.restart()

func _on_land() -> void:
	rotation_degrees = 0.0
	_land_cooldown = 0.2
	_squash_then_recover(Vector2(LAND_SQUASH_X, LAND_SQUASH_Y))
	_land_particles.restart()

# REVERTED: back to the original snap-to-0-when-grounded tilt logic, no rolling
func _update_tilt(delta: float) -> void:
	if is_on_floor():
		rotation_degrees = lerp(rotation_degrees, 0.0, TILT_SPEED * delta)
		return
	var target_rot := TILT_UP_DEG if velocity.y < 0.0 else TILT_DOWN_DEG
	if not _facing_right:
		target_rot = -target_rot
	rotation_degrees = lerp(rotation_degrees, target_rot, TILT_SPEED * delta)

func _create_dust_particles(dir: Vector2, spread_deg: float, speed: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	add_child(p)
	var sprite_height = _sprite.get_sprite_frames().get_frame_texture(_sprite.animation, _sprite.frame).get_height()
	p.position = Vector2(0, sprite_height / 2.0)
	p.amount = 10
	p.lifetime = 0.4
	p.one_shot = true
	p.explosiveness = 1.0
	p.z_index = 5
	p.direction = dir
	p.spread = spread_deg
	p.gravity = Vector2(0, 180)
	p.initial_velocity_min = speed * 0.6
	p.initial_velocity_max = speed
	p.scale_amount_min = 4.0
	p.scale_amount_max = 7.0
	var curve := Gradient.new()
	curve.set_color(0, Color(0.9, 0.9, 0.9, 0.7))
	curve.set_color(1, Color(0.9, 0.9, 0.9, 0.0))
	p.color_ramp = curve
	return p

func _create_burst_particles() -> CPUParticles2D:
	var p := CPUParticles2D.new()
	add_child(p)
	p.position = Vector2.ZERO
	p.amount = 14
	p.lifetime = 0.35
	p.one_shot = true
	p.explosiveness = 1.0
	p.z_index = 5
	p.direction = Vector2(0, 0)
	p.spread = 180.0
	p.gravity = Vector2(0, 60)
	p.initial_velocity_min = 60.0
	p.initial_velocity_max = 140.0
	p.scale_amount_min = 3.0
	p.scale_amount_max = 6.0
	var curve := Gradient.new()
	curve.set_color(0, Color(1.0, 1.0, 0.8, 0.8))
	curve.set_color(1, Color(1.0, 1.0, 0.8, 0.0))
	p.color_ramp = curve
	return p

func _create_dash_particles() -> CPUParticles2D:
	var p := CPUParticles2D.new()
	add_child(p)
	p.position = Vector2.ZERO
	p.amount = 12
	p.lifetime = 0.25
	p.one_shot = true
	p.explosiveness = 1.0
	p.z_index = 5
	p.direction = Vector2(-1, 0)
	p.spread = 20.0
	p.gravity = Vector2.ZERO
	p.initial_velocity_min = 150.0
	p.initial_velocity_max = 250.0
	p.scale_amount_min = 3.0
	p.scale_amount_max = 6.0
	var curve := Gradient.new()
	curve.set_color(0, Color(0.6, 0.8, 1.0, 0.8))
	curve.set_color(1, Color(0.6, 0.8, 1.0, 0.0))
	p.color_ramp = curve
	return p
