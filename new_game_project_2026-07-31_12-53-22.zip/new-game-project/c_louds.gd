extends Node2D

# how far the clouds drift, in pixels
@export var float_amplitude_x: float = 6.0
@export var float_amplitude_y: float = 10.0

# how fast they float (lower = slower/lazier)
@export var float_speed: float = 0.5

var cloud_data := []

func _ready():
	for cloud in get_children():
		if cloud is Sprite2D:
			cloud_data.append({
				"node": cloud,
				"start_pos": cloud.position,
				"time_offset": randf() * TAU,
				"speed_mult": randf_range(0.7, 1.3)
			})

func _process(delta):
	var t = Time.get_ticks_msec() / 1000.0
	for data in cloud_data:
		var cloud = data.node
		var offset = data.time_offset
		var speed = float_speed * data.speed_mult

		var x_off = sin(t * speed + offset) * float_amplitude_x
		var y_off = sin(t * speed * 1.5 + offset) * float_amplitude_y

		cloud.position = data.start_pos + Vector2(x_off, y_off)
