extends CharacterBody2D

# --- Settings ---
@export var chase_speed: float = 100.0
@export var idle_hop_speed: float = 60.0
@export var jump_force: float = -250.0

@export var detection_radius: float = 400.0  # Range to spot Burger
@export var attack_range: float = 120.0      # Range for frame 1 switch

# --- Variables ---
var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var player: Node2D = null
var hop_cooldown: float = 0.0

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

func _physics_process(delta: float) -> void:
	# Apply Gravity
	if not is_on_floor():
		velocity.y += gravity * delta

	# Automatically locate "Burger" in the scene if not found yet
	if not player:
		player = get_tree().root.find_child("Burger", true, false)

	# Check distance to player if Burger exists
	if player:
		var distance = global_position.distance_to(player.global_position)
		
		if distance <= detection_radius:
			_chase_player(distance)
		else:
			_idle_hop(delta)
	else:
		_idle_hop(delta)

	move_and_slide()

# --- Chase Logic ---
func _chase_player(distance: float) -> void:
	var direction = sign(player.global_position.x - global_position.x)
	
	# Update sprite flip constantly
	if direction != 0:
		animated_sprite.flip_h = (direction > 0)

	# Active tracking: Always push velocity towards player
	velocity.x = direction * chase_speed

	# Jump continuously whenever touching the ground
	if is_on_floor():
		velocity.y = jump_force

	# Frame switching logic
	if distance <= attack_range:
		animated_sprite.frame = 1  # In range
	else:
		animated_sprite.frame = 0  # Out of range

# --- Idle Logic ---
func _idle_hop(delta: float) -> void:
	animated_sprite.frame = 0  # Always frame 0 when idle
	
	# Friction: stop sliding after landing when idle
	if is_on_floor():
		velocity.x = move_toward(velocity.x, 0, 15.0)

	# Countdown timer for random hops
	hop_cooldown -= delta
	if hop_cooldown <= 0.0 and is_on_floor():
		hop_cooldown = randf_range(1.5, 3.0)  # Random time until next hop
		
		# Pick random direction: -1 (left) or 1 (right)
		var random_dir = [-1, 1].pick_random()
		
		animated_sprite.flip_h = (random_dir > 0)
		velocity.x = random_dir * idle_hop_speed
		velocity.y = jump_force
